
package com.ejemplo.spring.proyect;

import org.springframework.data.repository.CrudRepository;


public interface IEmployeeDAO extends CrudRepository<Employee, Long>{
    
}
