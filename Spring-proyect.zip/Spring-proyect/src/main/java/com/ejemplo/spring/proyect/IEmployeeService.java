package com.ejemplo.spring.proyect;

import java.util.List;
 
public interface IEmployeeService {

    public Employee get(long id);

    public List<Employee> getAll();

    public void post(Employee employee);

    public void put(Employee employee, long id);

    public void delete(long id);
}
