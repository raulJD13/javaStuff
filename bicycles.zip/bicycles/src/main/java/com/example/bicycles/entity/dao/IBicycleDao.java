package com.example.bicycles.entity.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.bicycles.entity.models.Bicycle;

public interface IBicycleDao extends CrudRepository <Bicycle,Long>{

}
