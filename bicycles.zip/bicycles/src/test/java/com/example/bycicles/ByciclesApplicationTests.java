package com.example.bycicles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByciclesApplicationTests {

	@Test
	void contextLoads() {
	}

}
