package com.example.bycicles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ByciclesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ByciclesApplication.class, args);
	}

}
