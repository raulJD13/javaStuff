package com.example.bycicles.entity.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.bycicles.entity.models.Bicycle;

public interface IBicycleDao extends CrudRepository <Bicycle,Long>{

}
